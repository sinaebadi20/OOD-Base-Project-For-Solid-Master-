package services;

import constants.Notifier;
import constants.PaymentMethods;

public class ReservationService {

    private PaymentProcessor paymentProcessor = new PaymentProcessor();

    public void makeReservation(Reservation res, PaymentMethods paymentType, Notifier notifier) {
        System.out.println("Processing reservation for " + res.customer.name);

        // city discount
        if (res.customer.city.equals("Paris")) {
            System.out.println("Apply city discount for Paris!");
            res.room.price *= 0.9;
        }

        // -------- PAYMENT --------
        switch (paymentType) {
            case CARD:
                paymentProcessor.payByCard(res.totalPrice());
                break;

            case PAYPAL:
                paymentProcessor.payByPayPal(res.totalPrice());
                break;

            case CASH:
                paymentProcessor.payByCash(res.totalPrice());
                break;

            case ONSITE:
                paymentProcessor.payOnSite(res.totalPrice());
                break;

            default:
                System.out.println("There is no Payment Method");
                break;
        }

        // -------- INVOICE --------
        System.out.println("----- INVOICE -----");
        System.out.println("hotel.Customer: " + res.customer.name);
        System.out.println("hotel.Room: " + res.room.number + " (" + res.room.type + ")");
        System.out.println("Total: " + res.totalPrice());
        System.out.println("-------------------");

        // -------- NOTIFICATION --------

        MessageSender sender = null;

        switch (notifier) {
            case EMAIL:
                sender = new EmailSender();
                break;

            case SMS:
                sender = new SmsSender();
                break;

            default:
                System.out.println("There is no Message Provider");
                break;
        }

        // اگر فقط ایمیل انتخاب شده
        if (notifier == Notifier.EMAIL) {
            sender.sendEmail(res.customer.email, "Your reservation confirmed!");
        }

        // اگر SMS انتخاب شده → هم SMS بفرست هم ایمیل
        if (notifier == Notifier.SMS) {
            sender.sendSms(res.customer.mobile, "Your reservation confirmed!");
            // ارسال ایمیل دوم:
            sender = new EmailSender();
            sender.sendEmail(res.customer.email, "Your reservation confirmed !");
        }

    }
}
