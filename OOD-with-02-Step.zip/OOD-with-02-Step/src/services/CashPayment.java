package services;

public class CashPayment implements PaymentMethod {
    
    public void pay(double amount) {
        System.out.println("Paid by cash: " + amount);
    }
}
