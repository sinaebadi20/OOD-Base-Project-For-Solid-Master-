package services;

public class OnSitePayment implements PaymentMethod {
    
    public void pay(double amount) {
        System.out.println("Paid on site: " + amount);
    }
}
