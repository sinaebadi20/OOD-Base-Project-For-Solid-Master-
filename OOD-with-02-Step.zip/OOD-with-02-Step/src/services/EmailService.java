package services;

public interface EmailService {
    void sendEmail(String to, String message);
}
