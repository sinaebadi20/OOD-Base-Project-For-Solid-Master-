package services;

public class CardPayment implements PaymentMethod {
    
    public void pay(double amount) {
        System.out.println("Paid by card: " + amount);
    }
}
