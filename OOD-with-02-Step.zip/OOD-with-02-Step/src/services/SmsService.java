package services;

public interface SmsService {
    void sendSms(String to, String message);
}
