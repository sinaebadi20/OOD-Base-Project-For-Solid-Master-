package services;

import constants.Notifier;

public class ReservationService {

    public void makeReservation(Reservation res,
                                PaymentMethod payment,
                                EmailService emailService,
                                SmsService smsService,
                                Notifier notifier) {

        System.out.println("Processing reservation for " + res.customer.name);

        if(res.customer.city.equals("Paris")){
            System.out.println("Apply city discount for Paris!");
            res.room.price *= 0.9;
        }

        payment.pay(res.totalPrice());

        System.out.println("----- INVOICE -----");
        System.out.println("Customer: " + res.customer.name);
        System.out.println("Room: " + res.room.number + " (" + res.room.type + ")");
        System.out.println("Total: " + res.totalPrice());
        System.out.println("-------------------");

        switch (notifier){
            case EMAIL:
                emailService.sendEmail(res.customer.email, "Your reservation confirmed!");
                break;

            case SMS:
                smsService.sendSms(res.customer.mobile, "Your reservation confirmed!");
                break;
        }
    }
}
