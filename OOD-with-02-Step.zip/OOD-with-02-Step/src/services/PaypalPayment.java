package services;

public class PaypalPayment implements PaymentMethod {
    
    public void pay(double amount) {
        System.out.println("Paid by PayPal: " + amount);
    }
}
