package services;

public class SmsSender implements SmsService {
    
    public void sendSms(String to, String message) {
        System.out.println("SMS → " + message + " → " + to);
    }
}
