package services;

public class EmailSender implements EmailService {
    
    public void sendEmail(String to, String message) {
        System.out.println("EMAIL → " + message + " → " + to);
    }
}
