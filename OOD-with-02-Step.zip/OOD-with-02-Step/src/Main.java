import constants.Notifier;
import models.Customer;
import models.LuxuryRoom;
import models.Room;
import services.*;

public class Main {
    public static void main(String[] args) {

        Customer customer = new Customer("Ali", "ali@example.com", "09124483765", "Paris");
        Room room = new LuxuryRoom("203", 150);
        Reservation res = new Reservation(room, customer, 2);

        PaymentMethod payment = new PaypalPayment();
        EmailService email = new EmailSender();
        SmsService sms = new SmsSender();

        ReservationService service = new ReservationService();
        service.makeReservation(res, payment, email, sms, Notifier.SMS);
    }
}
